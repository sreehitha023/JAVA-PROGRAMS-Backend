package com.marketsimplified;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;


@WebServlet("/Response")

public class Servlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        
        Employee emp1 = new Employee(111,"akhila","Java", 300000);
        Employee emp2 = new Employee(121,"madhu","Human-Resource", 40000);
        Employee emp3 = new Employee(131,"sindhu","Graphic-Designer", 50000);
        Employee emp4 = new Employee(141,"lahari","Art-Music", 30000);
        Employee emp5 = new Employee(151,"siri","Java", 60000);
        Employee emp6 = new Employee(161,"sreehitha","DataBase", 50000);
        Employee emp7 = new Employee(171,"chinni","Testing", 100000);
        Employee emp8 = new Employee(181,"sree","Developer", 90000);
        Hashtable<Integer, Employee> data = new Hashtable<>();
        data.put(emp1.empid, emp1);
        data.put(emp2.empid, emp2);
        data.put(emp3.empid, emp3);
        data.put(emp4.empid, emp4);
        data.put(emp5.empid, emp5);
        data.put(emp6.empid, emp6);
        data.put(emp7.empid, emp7);
        data.put(emp8.empid, emp8);
        
        PrintWriter out = response.getWriter();
        
        String contenttype= request.getContentType();
        
        if(contenttype.equals("application/json")) {
            
            response.setContentType("application/json");
            
            StringBuffer jb= new StringBuffer();
            
            String line=null;
            
            BufferedReader reader=request.getReader();
            while((line=reader.readLine())!= null) 
            {
                jb.append(line);
                
            }
            JSONObject jsobj = new JSONObject(jb.toString());
            int empid=jsobj.getInt("empid");
            JSONObject tabledata= new JSONObject();
            if(data.containsKey(empid)) {
                
            tabledata.put("EmpCode",data.get(empid).empid );
            tabledata.put("Name", data.get(empid).name);
            tabledata.put("Department", data.get(empid).department);
            tabledata.put("Salary", data.get(empid).salary);
                
            }
            else 
            {
                out.println("Entered Invalid Id, Kindly Check It.");
            }
            out.print(tabledata);
            System.out.println(tabledata);
            
        }
        else 
        {
            out.println("Try Again...");
        }
    }
}