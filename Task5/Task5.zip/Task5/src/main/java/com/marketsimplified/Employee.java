package com.marketsimplified;
public class Employee
{
    public int empid;
        public String name;
        public String department;
        public double salary;
            public Employee(int empid, String name, String department, double salary) {
            super();
            this.empid = empid;
            this.name = name;
            this.department = department;
            this.salary = salary;
        }
            @Override
            public String toString() {
                return "  " + empid + " "+ name + " " + department + " " + salary
                        + " ";
            }
            
}